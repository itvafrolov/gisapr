<?php
class MySque extends MyFigure
{
    public $len; // obj MyLine!

    public function __construct($L)
    {
        $this->len = $L->dist;
    }

    public function getLen()
    {
        $out = $this->len;
        return $out;
    }

    public function CalcArea()
    {     
        $res = $this->getLen() * $this->getLen();
        //$res = $this->len->dist * $this->len->dist;
        return parent::CalcArea() + $res;

    }
    public function CalсPerimetr()
    {      
        $res = $this->len * 4;
        return parent::CalсPerimetr() + $res;
    } 
    public function DrawFigure()
    {
        $out = parent::DrawFigure();
        $out .=" КВАДРАТ";
        return $out;
    }

}

?>